#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <TinyGPSPlus.h>

const char* ssid = "Box Test";
const char* password = "12345678";

WebServer server(80);

Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28, &Wire);
Adafruit_SSD1306 display(128, 32, &Wire, -1);
TinyGPSPlus gps;

const int trigPins[] = {23, 32, 5, 4, 13};
const int echoPins[] = {26, 25, 14, 18, 19};
const char* usNames[] = {"45_Deg", "Front", "Back", "Left", "Right"};

// Cached sensor values, updated continuously in loop(), served instantly on request
float usDist[5] = {0, 0, 0, 0, 0};
int usIndex = 0;

float imuX = 0, imuY = 0, imuZ = 0;
bool lidarActive = false;
int lidarBytes = 0;

float readUS(int trig, int echo) {
  digitalWrite(trig, LOW);
  delayMicroseconds(2);
  digitalWrite(trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(trig, LOW);
  long duration = pulseIn(echo, HIGH, 15000); // shorter timeout = faster cycle
  return (duration == 0) ? -1 : duration * 0.034 / 2.0;
}

const char webpage[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html><head><style>
body{font-family:sans-serif;background:#111;color:#eee;padding:15px;}
h2{color:#4fc3f7;}
p{margin:6px 0;}
b{color:#aaa;}
</style></head><body>
<h2>Sensor Diagnostics</h2>
<p><b>BNO055 IMU:</b> X: <span id="ix">-</span> Y: <span id="iy">-</span> Z: <span id="iz">-</span></p>
<p><b>GPS:</b> <span id="gps">-</span></p>
<p><b>LiDAR:</b> <span id="lidar">-</span></p>
<p><b>Ultrasonic (cm):</b></p>
<p id="us">-</p>
<script>
function poll() {
  fetch('/data').then(r => r.json()).then(d => {
    document.getElementById('ix').innerText = d.ix.toFixed(1);
    document.getElementById('iy').innerText = d.iy.toFixed(1);
    document.getElementById('iz').innerText = d.iz.toFixed(1);
    document.getElementById('gps').innerText = d.gpsValid ? (d.lat.toFixed(6) + ', ' + d.lng.toFixed(6)) : 'Waiting for fix';
    document.getElementById('lidar').innerText = d.lidar ? ('UART Active (' + d.lidarBytes + ' bytes)') : 'No UART data';
    let usHtml = '';
    for (let i = 0; i < d.us.length; i++) {
      usHtml += d.names[i] + ': ' + (d.us[i] < 0 ? 'timeout' : d.us[i].toFixed(1)) + ' cm<br>';
    }
    document.getElementById('us').innerHTML = usHtml;
  }).finally(() => setTimeout(poll, 100));
}
poll();
</script>
</body></html>
)rawliteral";

void handleData() {
  String json = "{";
  json += "\"ix\":" + String(imuX) + ",\"iy\":" + String(imuY) + ",\"iz\":" + String(imuZ) + ",";
  json += "\"gpsValid\":" + String(gps.location.isValid() ? 1 : 0) + ",";
  json += "\"lat\":" + String(gps.location.lat(), 6) + ",\"lng\":" + String(gps.location.lng(), 6) + ",";
  json += "\"lidar\":" + String(lidarActive ? 1 : 0) + ",\"lidarBytes\":" + String(lidarBytes) + ",";
  json += "\"us\":[";
  for (int i = 0; i < 5; i++) {
    json += String(usDist[i]);
    if (i < 4) json += ",";
  }
  json += "],\"names\":[";
  for (int i = 0; i < 5; i++) {
    json += "\"" + String(usNames[i]) + "\"";
    if (i < 4) json += ",";
  }
  json += "]}";
  server.send(200, "application/json", json);
}

void setup() {
  Serial.begin(115200);
  Serial1.begin(115200, SERIAL_8N1, 27, 33);
  Serial2.begin(9600, SERIAL_8N1, 16, 17);

  for (int i = 0; i < 5; i++) {
    pinMode(trigPins[i], OUTPUT);
    pinMode(echoPins[i], INPUT);
  }

  Wire.begin(21, 22);
  bno.begin();

  if (display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(WHITE);
    display.setCursor(0, 0);
    display.println("Sensors Init OK");
    display.println("Connect to WiFi");
    display.display();
  }

  WiFi.softAP(ssid, password);
  IPAddress IP = WiFi.softAPIP();

  Serial.println();
  Serial.print("SSID: ");
  Serial.println(ssid);
  Serial.print("Password: ");
  Serial.println(password);
  Serial.print("URL: http://");
  Serial.println(IP);

  server.on("/", []() { server.send_P(200, "text/html", webpage); });
  server.on("/data", handleData);
  server.begin();
}

void loop() {
  server.handleClient();

  while (Serial2.available() > 0) {
    gps.encode(Serial2.read());
  }

  // IMU updated every loop (fast, non-blocking)
  sensors_event_t event;
  bno.getEvent(&event);
  imuX = event.orientation.x;
  imuY = event.orientation.y;
  imuZ = event.orientation.z;

  // LiDAR check
  lidarBytes = Serial1.available();
  lidarActive = lidarBytes > 0;
  while (Serial1.available()) Serial1.read();

  // Round-robin one ultrasonic sensor per loop iteration
  // avoids blocking server.handleClient() for 5x pulseIn() calls in a row
  usDist[usIndex] = readUS(trigPins[usIndex], echoPins[usIndex]);
  usIndex = (usIndex + 1) % 5;
}