#pragma once
// BNO055 in IMUPLUS mode: gyro + accelerometer, read up to 100 Hz.
// Yaw is relative to the first valid reading after startup, NOT magnetic north.
// Vehicle frame: yaw + left / - right, pitch + front down, roll + right side down.
// The existing 90-degree mounting conversion is preserved. Wire.begin() must run first.
#include <Arduino.h>

class ImuManager {
public:
  // Starts relative fusion; no magnetic-north alignment.
  // Returns false if the BNO055 does not answer.
  bool begin();

  // Reads the sensor; call often, it limits itself to one read per 10 ms.
  void update();

  float yawDeg() const;                       // relative vehicle yaw, -180..180
  bool headingReady() const { return _ready && _sampleValid && _lastUpdateMs != 0 && millis() - _lastUpdateMs <= 500; }
  float pitchDeg() const { return _pitchDeg; }  // ISO pitch, + = front down
  float rollDeg() const { return _rollDeg; }    // ISO roll, + = right side down

  // Calibration state 0 (none) .. 3 (fully calibrated): system, gyro, accel, magnetometer
  void calibration(uint8_t& sys, uint8_t& gyro, uint8_t& accel, uint8_t& mag) const;

private:

  bool _ready = false;
  bool _sampleValid = false;
  uint32_t _lastAttemptMs = 0;
  uint32_t _lastUpdateMs = 0;
  // Sensor-frame heading is clockwise; converted in yawDeg().
  float _fusionYawDeg = 0;
  // vehicle frame (ISO 8855)
  float _pitchDeg = 0, _rollDeg = 0;
  bool _headingZeroSet = false;
  float _headingZeroDeg = 0;  // first valid relative-fusion heading
  uint8_t _cal[4] = {0, 0, 0, 0};
};
