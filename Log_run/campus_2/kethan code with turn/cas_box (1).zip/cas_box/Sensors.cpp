#include "Sensors.h"
#include <Wire.h>

static const uint8_t kImuAddr = 0x28;
static const uint32_t kSnapshotMs = 250;
static const uint32_t kImuRetryMs = 5000;

bool i2cPresent(uint8_t addr) {
  Wire.beginTransmission(addr);
  return Wire.endTransmission() == 0;
}

void Sensors::begin(int lidarOffsetDeg) {
  _lidarOffsetDeg = lidarOffsetDeg;
  Wire.begin(21, 22);                 // I2C: IMU + OLED

  _us.begin(kUsMaxCm, 17500);         // 17.5 ms echo timeout ~ 3 m

  LidarScan::Config lc;               // GPIO27/33, 230400 baud, filtering see LidarScan.h
  _lidar.begin(Serial1, lc);

  _gps.begin();                       // Serial2, GPIO16/17, 9600 baud
}

void Sensors::update() {
  _lidar.update();  // drain both UARTs every pass
  const uint32_t packets=_lidar.packets();
  if(packets!=_wallPacketCount){_wallPacketCount=packets;_wallPacketMs=millis();}
  _gps.poll();
  if (_imuReady) _imu.update(); else _startImuIfPresent();

  const uint32_t now = millis();
  if (now - _lastSnapMs < kSnapshotMs) return;
  _lastSnapMs = now;

  _usCm[0] = _us.readFrontCm();
  _usCm[1] = _us.readLeftCm();
  _usCm[2] = _us.readRightCm();
  _usCm[3] = _us.readBackCm();
  _usCm[4] = _us.readFrontAngledCm();
  _snapshotLidar();
  _snapshotGps();
  if (_imuReady) {
    _yaw = _imu.yawDeg();
    _pitch = _imu.pitchDeg();
    _roll = _imu.rollDeg();
    _imu.calibration(_cal[0], _cal[1], _cal[2], _cal[3]);
  }
}

// Start relative gyro/accelerometer fusion when the IMU becomes available.
void Sensors::_startImuIfPresent() {
  const uint32_t now = millis();
  if (now - _lastImuTryMs < kImuRetryMs) return;
  _lastImuTryMs = now;
  if (!i2cPresent(kImuAddr)) return;
  Serial.println("[sensors] BNO055 found, starting relative IMU");
  _imuReady = _imu.begin();
}

// Packet rate, checksum errors and the 90-point view (closest reliable bin per 4 deg).
void Sensors::_snapshotLidar() {
  const uint32_t now = millis();
  if (now - _lastPpsMs >= 1000) {
    const uint32_t packets = _lidar.packets();
    _lidarPps = (packets - _lastPackets) * 1000.0f / (now - _lastPpsMs);
    _lastPackets = packets;
    _lastPpsMs = now;
  }
  _lidarOk = _lidarPps > 1;
  _lidarCrcPct = _lidar.crcErrorPct();

  const int degPerPoint = 360 / kLidarPoints;
  for (uint8_t i = 0; i < kLidarPoints; i++) _lidarCm[i] = 0;
  for (int bin = 0; bin < 360; bin++) {
    const uint16_t mm = _lidar.distanceMm(bin);
    if (!mm) continue;
    const int deg = ((bin + _lidarOffsetDeg) % 360 + 360) % 360;
    const uint8_t i = deg / degPerPoint;
    const uint16_t cm = mm / 10;
    if (_lidarCm[i] == 0 || cm < _lidarCm[i]) _lidarCm[i] = cm;
  }
}

// A nearby, long, approximately parallel wall; observing any distant wall is insufficient.
bool Sensors::wallScanFresh() const {
  return _wallPacketCount != 0 && millis() - _wallPacketMs <= 200;
}

bool Sensors::leftWall(float& distanceCm, float* headingOffsetDeg, bool* extendsAhead) const {
  if (extendsAhead) *extendsAhead = false;
  if (!wallScanFresh()) return false;
  float sx=0,sy=0,sxx=0,sxy=0,syy=0,lo=1000,hi=-1000;
  int n=0, beside=0, ahead=0;
  for (int deg=210;deg<=330;deg+=2) {
    const float cm=_lidar.distanceMm((deg-_lidarOffsetDeg+720)%360)/10.0f;
    if (cm<40 || cm>350) continue;
    const float x=cm*cosf(deg*DEG_TO_RAD),y=cm*sinf(deg*DEG_TO_RAD);
    if (fabsf(x)>60 || y>-40 || y<-300) continue;
    sx+=x;sy+=y;sxx+=x*x;sxy+=x*y;syy+=y*y;++n;
    if (fabsf(x)<15) ++beside;
    if (x >= 15) ++ahead;
    lo=min(lo,x);hi=max(hi,x);
  }
  if (n<10 || beside<3 || hi-lo<60) return false;
  const float den=sxx-sx*sx/n;
  if (den<100) return false;
  const float a=(sxy-sx*sy/n)/den,b=(sy-a*sx)/n;
  const float residual=max(0.0f,(syy+a*a*sxx+n*b*b-2*a*sxy-2*b*sy+2*a*b*sx)/n);
  distanceCm=-b;
  if(fabsf(a)>=0.25f || residual>=64)return false;
  // LiDAR coordinates use y right; vehicle yaw is positive left.
  if(headingOffsetDeg)*headingOffsetDeg=-atanf(a)*RAD_TO_DEG;
  // A fitted segment mostly behind the rover can be B's trailing edge.
  if (extendsAhead) *extendsAhead = ahead >= 3 && hi >= 30;
  return true;
}

bool Sensors::turnLandmark(float& behindCm, float& rightCm) const {
  if (!wallScanFresh()) return false;

  // At the marked pose the board spans bins 30–35 and lies about 170 cm behind.
  // Scan a wider sector so the same segment is visible on approach.
  int count = 0, bestCount = 0, missing = 0;
  float minBehind = 0, maxBehind = 0, minRight = 0, maxRight = 0;
  float sumBehind = 0, sumRight = 0;
  for (int i = 25; i <= 38; ++i) {
    const float angle = (i * 4 + 2) * DEG_TO_RAD;
    const float range = i < 38 ? _lidarCm[i] : 0;
    const float behind = -range * cosf(angle);
    const float right = range * sinf(angle);
    const bool usable = behind >= 80 && behind <= 205 && right >= 115 && right <= 290;
    if (!usable && count && i < 38 && missing == 0) {
      ++missing;
      continue;
    }
    if (count && (!usable || behind > minBehind + 36 || behind < maxBehind - 36)) {
      if (count >= 4 && count > bestCount && maxRight - minRight >= 55) {
        bestCount = count;
        behindCm = sumBehind / count;
        rightCm = sumRight / count;
      }
      count = 0;
    }
    if (!usable) continue;
    missing = 0;

    if (!count) {
      minBehind = maxBehind = behind;
      minRight = maxRight = right;
      sumBehind = sumRight = 0;
    }
    minBehind = fminf(minBehind, behind);
    maxBehind = fmaxf(maxBehind, behind);
    minRight = fminf(minRight, right);
    maxRight = fmaxf(maxRight, right);
    sumBehind += behind;
    sumRight += right;
    ++count;
  }
  return bestCount != 0;
}

bool Sensors::frontWallWithin(float distanceCm) const {
  if (!wallScanFresh()) return false;
  int hits = 0;
  float near = distanceCm, far = 0;
  float leftEdge = 0, rightEdge = 0;
  for (int i = -9; i < 9; ++i) {
    const float angle = (i * 4 + 2) * DEG_TO_RAD;
    const int bin = (i * 4 + 2 - _lidarOffsetDeg + 720) % 360;
    const float range = _lidar.distanceMm(bin) / 10.0f;
    const float forward = range * cosf(angle);
    if (forward < 20 || forward > distanceCm) continue;

    const float side = range * sinf(angle);
    near = fminf(near, forward);
    far = fmaxf(far, forward);
    leftEdge = fminf(leftEdge, side);
    rightEdge = fmaxf(rightEdge, side);
    ++hits;
  }
  return hits >= 6 && leftEdge <= -12 && rightEdge >= 12 && far - near <= 20;
}

void Sensors::_snapshotGps() {
  _gpsFix = _gps.hasFix();
  if (_gpsFix) {
    _lat = _gps.latDeg();
    _lon = _gps.lonDeg();
  }
  _sats = _gps.satellites();
  _hdop = _gps.hdop();
  _gpsChars = _gps.charsReceived();
}

// {"us":[5 x cm],"usMax":..,"lidar":{ok,pps,crc,d:[90 x cm]},"imu":{ok,yaw,pitch,roll,cal:[4]},
//  "gps":{fix,sats,hdop,lat,lon,chars}}
String Sensors::toJson() const {
  String j;
  j.reserve(720);
  j += "{\"us\":[";
  for (int i = 0; i < 5; i++) { if (i) j += ','; j += _usCm[i]; }
  j += "],\"usMax\":"; j += kUsMaxCm;
  j += ",\"lidar\":{\"ok\":"; j += _lidarOk ? "true" : "false";
  j += ",\"pps\":"; j += String(_lidarPps, 0);
  j += ",\"crc\":"; j += String(_lidarCrcPct, 1);
  j += ",\"d\":[";
  for (int i = 0; i < kLidarPoints; i++) { if (i) j += ','; j += _lidarCm[i]; }
  j += "]},\"imu\":{\"ok\":"; j += _imuReady ? "true" : "false";
  j += ",\"yaw\":"; j += String(_yaw, 1);
  j += ",\"pitch\":"; j += String(_pitch, 1);
  j += ",\"roll\":"; j += String(_roll, 1);
  j += ",\"cal\":["; j += _cal[0]; j += ','; j += _cal[1]; j += ','; j += _cal[2]; j += ','; j += _cal[3];
  j += "]},\"gps\":{\"fix\":"; j += _gpsFix ? "true" : "false";
  j += ",\"sats\":"; j += _sats;
  j += ",\"hdop\":"; j += String(_hdop, 1);
  j += ",\"lat\":"; j += String(_lat, 6);
  j += ",\"lon\":"; j += String(_lon, 6);
  j += ",\"chars\":"; j += _gpsChars;
  j += "}}";
  return j;
}
