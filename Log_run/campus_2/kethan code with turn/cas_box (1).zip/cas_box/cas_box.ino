// =============================================================================================
//  CAS Box - starter program for the sensor box on the WAVE ROVER
//  Case Study Cooperative and Autonomous Systems, version 1.0 (2026-10-15)
// =============================================================================================
//
//  WHAT IT DOES
//    The box ESP32 is the "brain" of your robot. It opens its own Wi-Fi, serves a web page for
//    your phone, reads all box sensors and drives the WAVE ROVER underneath it over Wi-Fi.
//
//      phone ──Wi-Fi──► box (this program): web page, sensors ──Wi-Fi──► rover (motors)
//
//    Web page: drive pad (hold a key = drive, release = stop), speed slider, LiDAR top view,
//    ultrasonic distances, IMU (roll/pitch/yaw), GPS. "Dev" (top right) shows raw values.
//
//  BEFORE YOU FLASH: set BOX_ID below to the number of your kit (sticker on box and rover).
//    Everything else follows from it - do not change the naming scheme:
//      Wi-Fi name  CAS-Box-<NN>      e.g. kit 7 -> CAS-Box-07
//      password    CASbox<NN>        e.g. kit 7 -> CASbox07
//      web page    http://192.168.<10+N>.1   e.g. kit 7 -> http://192.168.17.1
//      channel     odd kits 1, even kits 11
//    Your rover is already set up to join exactly this Wi-Fi. A wrong BOX_ID means: your rover
//    does not find your box, or your box takes over another team's network.
//
//  START ORDER: switch on the box first, then the rover (the rover looks for its box only
//    while it boots). Phone: join CAS-Box-<NN>, open the web page.
//
//  ARDUINO IDE: board "ESP32 Dev Module", ESP32 core 3.3.x, default partition scheme.
//    Required libraries and versions: README.md. Serial monitor: 115200 baud.
//
//  FILES
//    cas_box.ino        this file: settings, setup(), loop()
//    RoverLink.*        box -> rover link (sends drive commands, reads battery voltage)
//    Sensors.*          all sensors behind one object (ultrasonic, LiDAR, IMU, GPS)
//    LidarScan.h        LiDAR (LD20) reader with noise filtering
//    WebHMI.*           web server and web page
//    UsManager.*        5 ultrasonic sensors (HC-SR04), measured in a background task
//    ImuManager.*       orientation sensor BNO055 (roll / pitch / yaw in the ISO 8855 vehicle frame)
//    GpsManager.*       GPS module NEO-6M
//    DisplayManager.*   small OLED on the box
//
//  SAFETY / BEHAVIOUR
//    The rover stops when you release the key, when the page loses focus, when the box gets no
//    update from the phone for 0.4 s, when RoverLink gets no new set point for 0.5 s, and - in
//    the rover itself - after 3 s without a command. Do not remove these stops.
//    The rover firmware must not be changed.
// =============================================================================================

#include "WebHMI.h"
#include "RoverLink.h"
#include "Sensors.h"
#include "DisplayManager.h"
#include <math.h>

// ---- YOUR KIT ------------------------------------------------------------------------------
const int BOX_ID = 4;                     // 1..10 = kit number on the box

// ---- settings --------------------------------------------------------------------------------
const float MAX_SPEED = 0.5f;             // drive pad maximum; 0.5 = full rover speed (100 % PWM)
const uint32_t TURN_TEST_PHONE_TIMEOUT_MS = 5000; // tolerate brief phone delays during button turn tests
const uint32_t PAD_TIMEOUT_MS = 2000;      // no update from the phone for this long -> stop
const int LIDAR_OFFSET_DEG = 90;          // rotates the LiDAR view so that "front" is up

const int US_FRONT_STOP_CM = 35;
const int US_SIDE_STOP_CM = 15;
const uint32_t US_WAIT_MS = 500;
const uint32_t US_ARC_MS = 400; // bounded forward arc; not a measured turning angle
const float GO_TEST_SPEED = 0.25f;
const uint32_t GO_WALL_CONFIRM_MS = 600;
const uint32_t GO_TURN_SETTLE_MS = 350;
const float GO_MARKER_MIN_BEHIND_CM = 164.0f;
const float GO_MARKER_MAX_BEHIND_CM = 183.0f;
const uint32_t GO_MARKER_MEMORY_MS = 1000; // retain a confirmed approach through a brief missed reading
const float GO_NEXT_WALL_CM = 80.0f;
const uint32_t GO_FRONT_WALL_CHECK_MS = 100;
const uint32_t GO_AFTER_TURN_PHONE_RESUME_MS = 2000;
const float LEFT_WALL_TARGET_CM = 80.0f; // LiDAR centre to left wall
const uint32_t WALL_UPDATE_MS = 50;      // up to 20 Hz geometry processing
const float WALL_MAX_OFFSET_DEG = 3.0f;  // limited support around the saved gyro heading
const float RIGHT_TURN_SPEED = 0.50f; // automatic right turn, outdoor setting
const float RIGHT_TURN_TEST_SPEED = 0.50f; // Right 90 button, outdoor trial
const float RIGHT_TURN_STOP_AT_DEG = 83.0f; // automatic right turn, outdoor cutoff
const float LEFT_TURN_TEST_SPEED = 0.50f; // Left 90 button, outdoor trial
const float LEFT_TURN_TEST_STOP_AT_DEG = 86.0f; // tune separately from right turns
const float RIGHT_TURN_TEST_STOP_AT_DEG = 86.0f; // outdoor trial at 0.50

// ---- objects ---------------------------------------------------------------------------------
WebHMI hmi;           // web server + page
RoverLink rover;      // connection to the rover
Sensors sensors;      // all box sensors
DisplayManager disp;  // small OLED on the box
bool oledReady = false;
char boxSsid[16], boxPassword[16];

// Lightweight left-wall observation; no map, pillar counting or route turns.
bool wallVisible=false, wallExtendsAhead=false;
float leftWallCm=0,leftWallAngleDeg=0,wallSteerDeg=0;
uint32_t wallViewMs=0,wallFrame=0;
void updateLeftWall() {
  const uint32_t now=millis();if(now-wallViewMs<WALL_UPDATE_MS)return;
  wallViewMs=now;++wallFrame;
  wallVisible = sensors.leftWall(leftWallCm, &leftWallAngleDeg, &wallExtendsAhead);
  if(!wallVisible)leftWallCm=leftWallAngleDeg=0;
}

// Gyro-based heading hold for the forward arrow only; manual turns/reverse are unchanged.
enum class GoStage { FollowB, CrossGap, FollowC, TurnRight, AfterTurn, TurnAtE, FindE, FollowE };
GoStage goStage = GoStage::FollowB;
bool goTestActive = false;
uint32_t goTurnStoppedSince = 0;
const char* goTestStatus = "";
const char* lastGoStopReason = nullptr;

String obstacleStatus;
bool headingHolding = false;
float headingTargetDeg = 0, headingCorrection = 0;
uint32_t headingControlMs = 0;

float headingErrorDeg(float target, float yaw) {
  float e = fmodf(target - yaw + 180.0f, 360.0f);
  if (e < 0) e += 360.0f;
  return e - 180.0f;
}

void steerForward(float& l, float& r) {
  static float previousYaw = 0, yawRate = 0, baseHeading = 0;
  static uint32_t lastWallFrame=0,wallSince=0;
  const bool forward = l > 0 && r > 0 && fabsf(l-r) < 0.0001f;
  if (!forward || !sensors.headingReady()) {
    headingHolding = false; headingCorrection = 0; headingControlMs = 0;
    wallSteerDeg=0;wallSince=0;
    if (forward) l = r = 0; // No gyro steering with a missing/invalid reading.
    return;
  }
  const uint32_t now = millis();
  const float yaw = sensors.yawNowDeg();
  if (!headingHolding) {
    headingHolding = true; baseHeading=headingTargetDeg=yaw; previousYaw=yaw;
    wallSteerDeg=0;wallSince=0;lastWallFrame=wallFrame;
    yawRate = headingCorrection = 0; headingControlMs = now;
  }
  if(lastWallFrame!=wallFrame){
    lastWallFrame=wallFrame;
    const bool gyroOnly = goTestActive &&
        (goStage == GoStage::CrossGap || goStage == GoStage::AfterTurn);
    if (wallVisible && !gyroOnly) {
      if(!wallSince)wallSince=now;
      if(now-wallSince>=400&&obstacleStatus.length()==0){
        const float distanceError=leftWallCm-LEFT_WALL_TARGET_CM;
        const float outsideBand=fabsf(distanceError)<=5?0:distanceError-(distanceError>0?5:-5);
        const float wallHeading=headingErrorDeg(yaw+leftWallAngleDeg,0);
        const float wanted=constrain(0.25f*headingErrorDeg(wallHeading,baseHeading)+0.15f*outsideBand,
                                     -WALL_MAX_OFFSET_DEG,WALL_MAX_OFFSET_DEG);
        wallSteerDeg+=constrain(wanted-wallSteerDeg,-0.05f,0.05f); // 1 degree/second
      }
    }else wallSince=0; // Keep the last guided heading through a wall gap.
    headingTargetDeg=headingErrorDeg(baseHeading+wallSteerDeg,0);
  }
  if (now - headingControlMs >= 10) { // up to 100 Hz
    const float dt = (now - headingControlMs) / 1000.0f;
    headingControlMs = now;
    const float retain = powf(0.7f, dt / 0.02f);
    yawRate = dt < 0.1f ? retain*yawRate + (1-retain)*headingErrorDeg(yaw,previousYaw)/dt : 0;
    previousYaw = yaw;
    const float error = headingErrorDeg(headingTargetDeg,yaw);
    const float limit = fminf(0.10f,l*0.4f);
    const float wanted = constrain((fabsf(error)>0.5f ? 0.045f*error : 0)-0.0015f*yawRate,-limit,limit); // stronger forward heading correction
    if (dt >= 0.1f) headingCorrection = 0;
    else headingCorrection += constrain(wanted-headingCorrection,-0.30f*dt,0.30f*dt);
    headingCorrection = constrain(headingCorrection,-limit,limit);
  }
  const float speed = l;
  l = speed-headingCorrection; r = speed+headingCorrection;
  const float peak = fmaxf(l,r);
  if (peak > MAX_SPEED) { l *= MAX_SPEED/peak; r *= MAX_SPEED/peak; }
}

// Forward-arrow obstacle handling. Release/manual control cancels an automatic arc.
void avoidUltrasonic(bool forwardRequested, float& l, float& r) {
  enum Phase { DRIVE, WAIT, ARC, BLOCKED };
  static Phase phase = DRIVE;
  static uint32_t waitStarted = 0, clearSince = 0, arcStarted = 0;
  static int turn = 0, attempts = 0;
  if (!forwardRequested) { phase=DRIVE; attempts=0; clearSince=0; obstacleStatus=""; return; }
  const uint32_t now=millis();
  const int cm[3]={sensors.usCm(0),sensors.usCm(1),sensors.usCm(2)};
  const char* name[3]={"Front","Left","Right"};
  auto limit=[&](int i){return i==0?US_FRONT_STOP_CM:US_SIDE_STOP_CM;};
  auto invalid=[&](int i){return cm[i]!=-2&&(cm[i]<2||cm[i]>Sensors::kUsMaxCm);};
  auto close=[&](int i){return cm[i]>=2&&cm[i]<=limit(i);};
  // No echo is allowed for ordinary forward driving, but never approves an avoidance arc.
  auto clear=[&](int i){return cm[i]==-2||cm[i]>limit(i);};
  int bad=-1,hit=-1;
  for(int i=0;i<3;++i){if(invalid(i)&&bad<0)bad=i;if(close(i)&&hit<0)hit=i;}
  const float speed=fminf(0.20f,fmaxf(l,r));
  if (!sensors.headingReady()) { l=r=0; obstacleStatus="STOP: IMU invalid/stale"; return; }
  if (bad>=0) {
    l=r=0; clearSince=0;
    if(phase==ARC){phase=WAIT;waitStarted=now;}
    obstacleStatus=String("STOP: US ")+name[bad]+" invalid/stale";return;
  }
  if(phase==BLOCKED){l=r=0;obstacleStatus="STOP: avoidance limit; release forward to reset";return;}
  if(phase==DRIVE && hit<0){obstacleStatus="";return;}
  if(phase==DRIVE){phase=WAIT;waitStarted=now;clearSince=0;}
  if(phase==WAIT){
    l=r=0;
    if(clear(0)&&clear(1)&&clear(2)){if(!clearSince)clearSince=now;}else clearSince=0;
    const String source=hit>=0?String("US ")+name[hit]+" "+String(cm[hit])+" cm":"US clearance";
    if(now-waitStarted<US_WAIT_MS){obstacleStatus="Wait 0.5 seconds: "+source;return;}
    if(clearSince&&now-clearSince>=600){phase=DRIVE;attempts=0;obstacleStatus="Path cleared; resuming saved heading";return;}
    if(close(0)||!clear(0)){obstacleStatus="STOP: US Front blocked; automatic pivots disabled";return;}
    // Require measured front and destination-side clearance, not a no-echo assumption.
    turn=close(2)&&cm[0]>US_FRONT_STOP_CM+10&&cm[1]>US_SIDE_STOP_CM+10?1:
         close(1)&&cm[0]>US_FRONT_STOP_CM+10&&cm[2]>US_SIDE_STOP_CM+10?-1:0;
    if(!turn){obstacleStatus="STOP: no measured clearance for forward arc | "+source;return;}
    if(attempts>=3){phase=BLOCKED;obstacleStatus="STOP: avoidance limit; release forward to reset";return;}
    ++attempts;phase=ARC;arcStarted=now;
  }
  if(phase==ARC){
    const int destination=turn>0?1:2;
    if(cm[0]<=US_FRONT_STOP_CM+10||cm[destination]<=US_SIDE_STOP_CM+10||now-arcStarted>=US_ARC_MS){
      l=r=0;phase=WAIT;waitStarted=now;clearSince=0;
      obstacleStatus="Arc ended; checking ultrasonic clearance";return;
    }
    // Both sides forward. The saved IMU target is retained throughout the pause/arc.
    l=turn>0?speed*0.4f:speed;r=turn>0?speed:speed*0.4f;
    obstacleStatus=turn>0?"US Right: forward arc left":"US Left: forward arc right";
  }
}

// Deliberate 90-degree test: original right-arrow pivot, separate from forward avoidance.
bool rightTurnActive=false;
float rightTurnTargetDeg=0,rightTurnProgressDeg=0;
String rightTurnStatus;
bool controlRightTurn90(uint32_t token, uint32_t ageMs, bool routeTurn, bool goWithoutPhone, bool turnLeft, float& l, float& r) {
  static uint32_t currentToken=0,started=0,lastControl=0,responseMs=0;
  static float previousYaw=0,responseProgress=0,command=0;
  static bool currentRouteTurn = false, currentTurnAtE = false, currentLeft = false;
  const bool leftTurn = !routeTurn && turnLeft;
  const float direction = leftTurn ? -1.0f : 1.0f;
  const String label = leftTurn ? "Left 90" : "Right 90";
  const bool turnAtE = routeTurn && goStage == GoStage::TurnAtE;
  if(!token){
    if(rightTurnActive)rightTurnStatus="90-degree turn cancelled";
    rightTurnActive=false;return false;
  }
  l=r=0;
  auto finish = [&](const String& reason, bool succeeded = false) {
    rightTurnActive = false;
    rightTurnStatus = reason;
    l = r = 0;
    if (routeTurn) {
      if (succeeded) {
        goStage = turnAtE ? GoStage::FindE : GoStage::AfterTurn;
        goTurnStoppedSince = millis();
        goTestStatus = "Go to H: right turn complete, settling";
      } else {
        goTestActive = false;
        goTestStatus = "";
        hmi.finishGoToH(token);
      }
    } else {
      hmi.finishRightTurn(token);
    }
  };
  const uint32_t now=millis();
  if (token != currentToken || routeTurn != currentRouteTurn || turnAtE != currentTurnAtE || leftTurn != currentLeft) {
    currentLeft = leftTurn;
    currentRouteTurn = routeTurn;
    currentTurnAtE = turnAtE;
    currentToken=token;rightTurnActive=true;started=responseMs=now;lastControl=0;
    rightTurnProgressDeg=responseProgress=0;command=0;
    if(sensors.headingReady())previousYaw=sensors.yawNowDeg();
    rightTurnTargetDeg=headingErrorDeg(previousYaw-direction*90,0);
  }
  if(!rightTurnActive)return true; // A completed token cannot restart via a late heartbeat.
  const uint32_t phoneTimeoutMs = routeTurn ? PAD_TIMEOUT_MS : TURN_TEST_PHONE_TIMEOUT_MS;
  if (ageMs > phoneTimeoutMs && !(routeTurn && goWithoutPhone)) {
    finish(String("STOP: ")+label+" phone timeout");
    return true;
  }
  if(!rover.connected()){finish(String("STOP: ")+label+" rover disconnected");return true;}
  if(!sensors.headingReady()){finish(String("STOP: ")+label+" IMU invalid/stale");return true;}
  const char* names[3]={"Front","Left","Right"};
  for(int i=0;i<3;++i){
    const int cm=sensors.usCm(i),limit=i==0?US_FRONT_STOP_CM:US_SIDE_STOP_CM;
    if(cm!=-2&&(cm<2||cm>Sensors::kUsMaxCm||cm<=limit)){
      finish(String("STOP: ")+label+" | US "+names[i]+" "+(cm<2?String("invalid/stale"):String(cm)+" cm"));return true;
    }
  }
  if(now-started>15000){finish(String("STOP: ")+label+" exceeded 15 seconds");return true;}
  if(lastControl&&now-lastControl<10){l=direction*command;r=-direction*command;return true;}
  lastControl=now;
  const float yaw=sensors.yawNowDeg();
  const float delta=headingErrorDeg(yaw,previousYaw);previousYaw=yaw;
  if(fabsf(delta)>30){finish(String("STOP: ")+label+" unexpected IMU jump");return true;}
  rightTurnProgressDeg-=direction*delta; // Accumulate either direction through +/-180.
  if(rightTurnProgressDeg< -5){finish(String("STOP: ")+label+" turned the wrong direction");return true;}
  const float stopAtDeg = routeTurn ? RIGHT_TURN_STOP_AT_DEG : (leftTurn ? LEFT_TURN_TEST_STOP_AT_DEG : RIGHT_TURN_TEST_STOP_AT_DEG);
  if (rightTurnProgressDeg >= stopAtDeg) {
    finish(label+": early stop commanded; check final yaw", true);
    return true;
  }
  if(rightTurnProgressDeg-responseProgress>=1){responseProgress=rightTurnProgressDeg;responseMs=now;}
  if(now-responseMs>2000){finish(String("STOP: ")+label+" no measured turn response");return true;}
  command = routeTurn ? RIGHT_TURN_SPEED : (leftTurn ? LEFT_TURN_TEST_SPEED : RIGHT_TURN_TEST_SPEED);
  l=direction*command;r=-direction*command;
  rightTurnStatus = (turnAtE ? String("Wall E right 90: ") : label+": ") + String(rightTurnProgressDeg,1) + " / 90 deg";
  return true;
}

void applyGoToH(uint32_t token, uint32_t age, bool goWithoutPhone, float& left, float& right) {
  static uint32_t lastToken = 0;
  static uint32_t lastWallFrame = 0, transitionSince = 0;
  static bool confirmingTransition = false;
  static uint32_t lastMarkerScan = 0, lastFrontWallCheck = 0, lastMarkerSeenMs = 0;
  static bool markerApproached = false;
  static float previousMarkerBehind = 0, previousMarkerRight = 0;
  static uint8_t markerConfirmations = 0, frontWallConfirmations = 0;
  if (!token) {
    if (goTestActive) {
      goTestStatus = "Go to H cancelled";
      lastGoStopReason = goTestStatus;
    }
    goTestActive = false;
    if (left != 0 || right != 0) goTestStatus = "";
    return;
  }

  left = right = 0;
  const uint32_t now = millis();
  const bool starting = token != lastToken;
  if (starting) {
    lastToken = token;
    goTestActive = true;
    goStage = wallVisible ? GoStage::FollowB : GoStage::CrossGap;
    confirmingTransition = false;
    lastWallFrame = wallFrame;
    lastMarkerScan = sensors.lidarSnapshotMs();
    markerApproached = false;
    lastMarkerSeenMs = 0;
    markerConfirmations = frontWallConfirmations = 0;
    lastFrontWallCheck = now;
    rightTurnStatus = "";
    steerForward(left, right);
    avoidUltrasonic(false, left, right);
  }
  if (!goTestActive) return;

  const char* reason = nullptr;
  const uint32_t phoneTimeout = goStage == GoStage::AfterTurn
      ? GO_AFTER_TURN_PHONE_RESUME_MS
      : PAD_TIMEOUT_MS;
  if (!goWithoutPhone && age > phoneTimeout) reason = "Go to H stopped: phone timeout";
  else if (!rover.connected()) reason = "Go to H stopped: rover disconnected";
  else if (!sensors.headingReady()) reason = "Go to H stopped: IMU invalid/stale";
  else if (!sensors.wallScanFresh()) reason = "Go to H stopped: LiDAR data stale";

  const bool checkingWall = goStage == GoStage::FollowB || goStage == GoStage::CrossGap ||
      goStage == GoStage::FollowC || goStage == GoStage::FollowE ||
      (goStage == GoStage::FindE && now - goTurnStoppedSince >= GO_TURN_SETTLE_MS);
  if (!reason && checkingWall && wallFrame != lastWallFrame) {
    lastWallFrame = wallFrame;
    const bool lookingForWall = goStage == GoStage::CrossGap || goStage == GoStage::FindE;
    const bool transitionDetected = lookingForWall
        ? wallVisible && wallExtendsAhead
        : !wallVisible;
    if (!transitionDetected) {
      confirmingTransition = false;
    } else if (!confirmingTransition) {
      confirmingTransition = true;
      transitionSince = now;
    } else if (now - transitionSince >= GO_WALL_CONFIRM_MS) {
      confirmingTransition = false;
      if (goStage == GoStage::FollowB) {
        goStage = GoStage::CrossGap;
      } else if (goStage == GoStage::CrossGap) {
        goStage = GoStage::FollowC;
      } else if (goStage == GoStage::FindE) {
        goStage = GoStage::FollowE;
      } else {
        reason = goStage == GoStage::FollowE
            ? "Go to H stopped: wall E lost"
            : "Go to H stopped: C wall lost";
      }
    }
  }

  if (!reason && goStage == GoStage::AfterTurn &&
      now - lastFrontWallCheck >= GO_FRONT_WALL_CHECK_MS) {
    lastFrontWallCheck = now;
    if (sensors.frontWallWithin(GO_NEXT_WALL_CM)) {
      if (++frontWallConfirmations >= 2) {
        goStage = GoStage::TurnAtE;
        goTurnStoppedSince = now;
        confirmingTransition = false;
      }
    } else {
      frontWallConfirmations = 0;
    }
  }

  bool markerTemporarilyMissing = false;
  if (!reason && goStage == GoStage::FollowC) {
    if (markerApproached && now - lastMarkerSeenMs > GO_MARKER_MEMORY_MS) {
      reason = "Go to H stopped: first-turn landmark lost";
    } else if (lastMarkerScan != sensors.lidarSnapshotMs()) {
      lastMarkerScan = sensors.lidarSnapshotMs();
      float behind = 0, right = 0;
      const bool detected = wallVisible && !obstacleStatus.length() &&
          sensors.turnLandmark(behind, right);
      if (detected && !markerApproached && behind <= 150) {
        markerApproached = true;
        markerConfirmations = 0;
        lastMarkerSeenMs = now;
        previousMarkerBehind = behind;
        previousMarkerRight = right;
      } else if (detected && markerApproached) {
        // Permit more forward movement across a missed scan, within the one-second memory.
        const float advanceLimit = fminf(65.0f,
            30.0f * fmaxf(1.0f, (now - lastMarkerSeenMs) / 250.0f));
        const bool sameLandmark = fabsf(right - previousMarkerRight) <= 55 &&
            behind >= previousMarkerBehind - 8 &&
            behind <= previousMarkerBehind + advanceLimit;
        if (!sameLandmark) {
          markerConfirmations = 0;
          markerTemporarilyMissing = true;
        } else if (behind > GO_MARKER_MAX_BEHIND_CM) {
          reason = "Go to H stopped: first-turn landmark passed";
        } else {
          lastMarkerSeenMs = now;
          previousMarkerBehind = behind;
          previousMarkerRight = right;
          if (behind >= GO_MARKER_MIN_BEHIND_CM) {
            if (++markerConfirmations >= 1) { // one fresh matching scan in the turn window
              goStage = GoStage::TurnRight;
              goTurnStoppedSince = now;
            }
          } else {
            markerConfirmations = 0;
          }
        }
      } else {
        // Preserve the approach, but a missing reading cannot count towards the turn.
        markerConfirmations = 0;
        markerTemporarilyMissing = markerApproached;
      }
    } else {
      markerTemporarilyMissing = markerApproached && now - lastMarkerSeenMs >= 250;
    }
  }

  if (reason) {
    goTestActive = false;
    goTestStatus = reason;
    lastGoStopReason = reason;
    rightTurnStatus = "";
    hmi.finishGoToH(token);
    return;
  }

  switch (goStage) {
    case GoStage::FollowB: goTestStatus = "Go to H: following B wall"; break;
    case GoStage::CrossGap: goTestStatus = "Go to H: crossing gap"; break;
    case GoStage::FollowC:
      goTestStatus = markerTemporarilyMissing
          ? "Go to H: following C, landmark briefly hidden"
          : "Go to H: following C wall";
      break;
    case GoStage::TurnRight: goTestStatus = "Go to H: landmark matched, preparing right turn"; return;
    case GoStage::TurnAtE: goTestStatus = "Go to H: wall E ahead, preparing right turn"; return;
    case GoStage::FindE:
      rightTurnStatus = "";
      goTestStatus = "Go to H: waiting for wall E on the left";
      return;
    case GoStage::FollowE: goTestStatus = "Go to H: following wall E"; break;
    case GoStage::AfterTurn:
      if (!goWithoutPhone && age > PAD_TIMEOUT_MS) {
        goTestStatus = "Go to H paused: waiting for phone updates";
        return;
      }
      if (now - goTurnStoppedSince < GO_TURN_SETTLE_MS) return;
      goTestStatus = "Go to H: straight after right turn";
      break;
  }
  left = right = GO_TEST_SPEED;
}

// OLED: Wi-Fi name, web address, rover state. Started only when the display answers on I2C.
void updateOled() {
  static uint32_t lastTry = 0;
  if (!oledReady) {
    if (millis() - lastTry < 5000) return;
    lastTry = millis();
    if (!i2cPresent(0x3C)) return;
    oledReady = disp.begin();
  }
  String ip = WiFi.softAPIP().toString();
  String r = rover.connected() ? "Rover " + String(rover.voltage(), 1) + "V" : "Rover: search";
  disp.show(boxSsid, ip.c_str(), r.c_str());
}

void setup() {
  Serial.begin(115200);
  delay(200);

  // naming scheme, derived from BOX_ID only (see header)
  snprintf(boxSsid, sizeof(boxSsid), "CAS-Box-%02d", BOX_ID);
  snprintf(boxPassword, sizeof(boxPassword), "CASbox%02d", BOX_ID);
  uint8_t channel = (BOX_ID % 2) ? 1 : 11;

  hmi.setTitle(String("CAS Box ") + BOX_ID);
  hmi.enableDrivePad(MAX_SPEED);
  hmi.setStateText("Starting ...");
  hmi.begin(boxSsid, boxPassword, IPAddress(192, 168, 10 + BOX_ID, 1), channel);

  sensors.begin(LIDAR_OFFSET_DEG);
  rover.begin(100);  // sends the current drive command every 100 ms
}

void loop() {
  uint32_t t0 = micros();
  hmi.tick();
  sensors.update();
  updateLeftWall();

  // ---- driving -------------------------------------------------------------------------------
  // Manual driving from the phone. For your own (autonomous) behaviour, compute l and r
  // yourself from the sensors, e.g. sensors.usCm(0) = front ultrasonic in cm, and call
  // rover.setDrive(l, r) every loop pass (range -0.5..0.5 per side).
  float l, r;
  uint32_t age, turnToken, goToken;
  bool goWithoutPhone, turnLeft;
  hmi.getDrive(l, r, age, turnToken, goToken, goWithoutPhone, turnLeft);
  if (age > PAD_TIMEOUT_MS) l = r = 0;  // key released, page closed or phone gone
  applyGoToH(goToken, age, goWithoutPhone, l, r);
  const bool routeTurn = goToken && goTestActive
      && (goStage == GoStage::TurnRight || goStage == GoStage::TurnAtE)
      && millis() - goTurnStoppedSince >= GO_TURN_SETTLE_MS;
  const uint32_t activeTurnToken = routeTurn ? goToken : turnToken;
  const bool pausedForPhone = goTestActive && !goWithoutPhone && goStage == GoStage::AfterTurn
      && age > PAD_TIMEOUT_MS;
  if (controlRightTurn90(activeTurnToken, age, routeTurn, goWithoutPhone, turnLeft, l, r)) {
    float zeroL=0,zeroR=0;steerForward(zeroL,zeroR);avoidUltrasonic(false,zeroL,zeroR);
  } else if (pausedForPhone) {
    // Stop the wheels and retain heading and obstacle state for this run.
    l = r = 0;
  } else {
    if(l!=0||r!=0)rightTurnStatus="";
    const bool forwardRequested = l>0 && r>0 && fabsf(l-r)<0.0001f;
    steerForward(l, r);
    avoidUltrasonic(forwardRequested,l,r);
  }
  rover.setDrive(l, r);

  // ---- web page and OLED -----------------------------------------------------------------------
  uint32_t now = millis();
  static uint32_t lastSnap = 0, lastUi = 0, lastOled = 0;
  if (now - lastSnap >= 250) {  // sensor snapshot for the page, 4 times per second
    lastSnap = now;
    hmi.setSensorJson(sensors.toJson());
  }
  if (now - lastUi >= 500) {  // status line + values in the "Dev" view
    lastUi = now;
    const String guidance=headingHolding?(wallVisible?" | Forward: left wall "+String(leftWallCm,0)+" cm; target 60 cm":" | Forward: gyro holds heading; left wall not visible"):"";
    String status = rover.statusText();
    if (!rightTurnStatus.length() && *goTestStatus) status += String(" | ") + goTestStatus;
    if (goTestActive && goWithoutPhone) status += " | Phone optional";
    if (goTestActive && lastGoStopReason) status += String(" | Previous run: ") + lastGoStopReason;
    if (rightTurnStatus.length()) status += " | " + rightTurnStatus;
    else if (obstacleStatus.length()) status += " | " + obstacleStatus;
    else if (!(goTestActive && goStage == GoStage::AfterTurn)) status += guidance;
    hmi.setStateText(status);
    hmi.showValue("rover.ip", rover.ip().toString());
    hmi.showValue("rover.voltage_V", rover.voltage());
    hmi.showValue("rover.rtt_ms", rover.rttMs());
    hmi.showValue("rover.ok", (double)rover.okCount());
    hmi.showValue("rover.fail", (double)rover.failCount());
    hmi.showValue("sys.heap_kB", ESP.getFreeHeap() / 1024.0);
    hmi.showValue("turn.target_deg",rightTurnTargetDeg);
    hmi.showValue("turn.progress_deg",rightTurnProgressDeg);
    hmi.showValue("wall.seen",wallVisible?1:0);
    hmi.showValue("wall.distance_cm",leftWallCm);
    hmi.showValue("wall.target_cm",LEFT_WALL_TARGET_CM);
    hmi.showValue("wall.steer_deg",wallSteerDeg);
    hmi.showValue("wall.angle_deg",leftWallAngleDeg);
    hmi.showValue("imu.holding",headingHolding ? 1 : 0);
    hmi.showValue("imu.target_deg",headingTargetDeg);
    hmi.showValue("imu.error_deg",sensors.headingReady() ? headingErrorDeg(headingTargetDeg,sensors.yawNowDeg()) : 0);
  }
  if (now - lastOled >= 1000) {
    lastOled = now;
    updateOled();
  }

  // ---- load report on Serial every 10 s (loop time, free memory, sensor snapshot) -------------
  static uint32_t lastRep = 0, n = 0, maxUs = 0;
  static uint64_t sumUs = 0;
  uint32_t dt = micros() - t0;
  n++; sumUs += dt; if (dt > maxUs) maxUs = dt;
  if (now - lastRep >= 10000) {
    Serial.printf("[sys] loop avg %.2f ms max %.1f ms, heap %u kB, rover %s\n",
                  sumUs / 1000.0 / n, maxUs / 1000.0, ESP.getFreeHeap() / 1024,
                  rover.connected() ? "ok" : "searching");
    Serial.printf("[sys] %s\n", sensors.toJson().c_str());
    lastRep = now; n = 0; sumUs = 0; maxUs = 0;
  }
  delay(2);
}
