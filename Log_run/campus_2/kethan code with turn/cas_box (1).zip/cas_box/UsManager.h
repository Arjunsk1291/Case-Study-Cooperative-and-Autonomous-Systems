#pragma once
// UsManager - the five HC-SR04 ultrasonic sensors of the box.
//
// A background task (core 0) measures sensors sequentially to reduce cross-talk and keeps
// the last distance of each; the read functions only return these cached values and never block.
// -2 = no echo, -1 = startup/invalid/stale. No echo does not prove clearance
// and cannot distinguish open space from a disconnected sensor.
// Echo lines go through a 1k/2k voltage divider (5 V sensor -> 3.3 V ESP32).
#include <Arduino.h>

class UsManager {
public:
  // GPIO pins (trigger / echo) as wired on the box PCB
  struct Pins {
    int trigFront = 32, echoFront = 25;
    int trigLeft = 4, echoLeft = 18;
    int trigRight = 13, echoRight = 19;
    int trigBack = 5, echoBack = 14;
    int trigFrontAngled = 23, echoFrontAngled = 26;
  };

  // Configures the pins and starts the measuring task.
  // timeoutUs: longest wait for an echo (17.5 ms ~ 3 m). Call once.
  void begin(int maxDistanceCm, uint32_t timeoutUs);

  // Latest cm; -2 no echo, -1 invalid/stale. Front/left/right: about 200-300 ms;
  // back/angled: about 1 s. Measurements continue while stopped.
  int readCm(uint8_t i) const;
  int readFrontCm() const { return readCm(0); }
  int readLeftCm() const { return readCm(1); }
  int readRightCm() const { return readCm(2); }
  int readBackCm() const { return readCm(3); }
  int readFrontAngledCm() const { return readCm(4); }

private:
  int _measureCm(int trigPin, int echoPin);  // one blocking measurement (task only)
  static void _taskEntry(void* self);
  void _taskLoop();

  Pins _pins;
  int _maxDistanceCm = 300;
  uint32_t _timeoutUs = 17500;
  TaskHandle_t _task = nullptr;

  mutable portMUX_TYPE _mux = portMUX_INITIALIZER_UNLOCKED;
  int _cm[5] = {-1,-1,-1,-1,-1};
  uint32_t _measuredMs[5] = {};
};
