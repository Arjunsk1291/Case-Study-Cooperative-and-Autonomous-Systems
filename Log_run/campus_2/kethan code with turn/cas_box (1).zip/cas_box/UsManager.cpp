#include "UsManager.h"

static const uint32_t kTriggerPeriodMs = 70; // trigger-to-trigger spacing; sequential sensors

void UsManager::begin(int maxDistanceCm, uint32_t timeoutUs) {
  if (_task) return;  // already running
  _maxDistanceCm = maxDistanceCm;
  _timeoutUs = timeoutUs;

  const int pins[5][2] = {{_pins.trigFront, _pins.echoFront}, {_pins.trigLeft, _pins.echoLeft},
                          {_pins.trigRight, _pins.echoRight}, {_pins.trigBack, _pins.echoBack},
                          {_pins.trigFrontAngled, _pins.echoFrontAngled}};
  for (auto& p : pins) {
    pinMode(p[0], OUTPUT);
    digitalWrite(p[0], LOW);
    pinMode(p[1], INPUT);
  }
  // low priority on core 0; loop() runs on core 1
  xTaskCreatePinnedToCore(_taskEntry, "ultrasonic", 4096, this, 1, &_task, 0);
}

// 10 us trigger pulse, then time the echo pulse. 58 us of echo = 1 cm distance.
int UsManager::_measureCm(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  const uint32_t us = pulseIn(echoPin, HIGH, _timeoutUs);  // blocks, but only in this task
  if (us == 0) return -2;  // no echo: distinct from invalid/stale data
  const int cm = us / 58;
  return (us < 116 || us > (uint32_t)_maxDistanceCm * 58) ? -1 : cm;
}

int UsManager::readCm(uint8_t i) const {
  if(i>=5)return -1;
  portENTER_CRITICAL(&_mux);
  const int cm=_cm[i];const uint32_t measured=_measuredMs[i];
  portEXIT_CRITICAL(&_mux);
  const uint32_t staleMs=i<3?1000:2500; // display-only sensors are sampled about once per second
  return millis()-measured>staleMs ? -1 : cm;
}

void UsManager::_taskEntry(void* self) { static_cast<UsManager*>(self)->_taskLoop(); }

// Prioritise front/left/right. Insert one display sensor after every second active sweep.
void UsManager::_taskLoop() {
  const int pins[5][2] = {{_pins.trigFront,_pins.echoFront},{_pins.trigLeft,_pins.echoLeft},
    {_pins.trigRight,_pins.echoRight},{_pins.trigBack,_pins.echoBack},
    {_pins.trigFrontAngled,_pins.echoFrontAngled}};
  bool displayDue=false;
  uint8_t displaySide=3;
  auto measure=[&](uint8_t i){
    const uint32_t started=millis();
    const int cm=_measureCm(pins[i][0],pins[i][1]);
    portENTER_CRITICAL(&_mux);
    _cm[i]=cm;_measuredMs[i]=millis();
    portEXIT_CRITICAL(&_mux);
    const uint32_t elapsed=millis()-started;
    // No catch-up bursts if this task is delayed. Yield only this background task.
    const uint32_t pause=elapsed<kTriggerPeriodMs?kTriggerPeriodMs-elapsed:kTriggerPeriodMs;
    vTaskDelay(max((TickType_t)1,pdMS_TO_TICKS(pause)));
  };
  for (;;) {
    for(uint8_t i=0;i<3;++i)measure(i);
    if(displayDue){
      measure(displaySide);
      displaySide=displaySide==3?4:3;
    }
    displayDue=!displayDue;
  }
}
