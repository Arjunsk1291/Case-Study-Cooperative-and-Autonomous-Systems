// =============================================================================================
//  CAS Box - starter program for the sensor box on the WAVE ROVER
//  cas_box_kethan_log (2026-11-05): Kethan's field-tested version + DriveLog (teaching drives) +
//  gradual start (every drive key rises from 0 to the slider value in 2.5 s, soft stop on release)
//  Case Study Cooperative and Autonomous Systems, version 1.0 (2026-10-15)
// =============================================================================================
//
//  WHAT IT DOES
//    The box ESP32 is the "brain" of your robot. It opens its own Wi-Fi, serves a web page for
//    your phone, reads all box sensors and drives the WAVE ROVER underneath it over Wi-Fi.
//
//      phone ──Wi-Fi──► box (this program): web page, sensors ──Wi-Fi──► rover (motors)
//
//    Web page: drive pad (hold a key = drive, release = stop), speed slider, LiDAR top view,
//    ultrasonic distances, IMU (roll/pitch/yaw), GPS. "Dev" (top right) shows raw values.
//
//  BEFORE YOU FLASH: set BOX_ID below to the number of your kit (sticker on box and rover).
//    Everything else follows from it - do not change the naming scheme:
//      Wi-Fi name  CAS-Box-<NN>      e.g. kit 7 -> CAS-Box-07
//      password    CASbox<NN>        e.g. kit 7 -> CASbox07
//      web page    http://192.168.<10+N>.1   e.g. kit 7 -> http://192.168.17.1
//      channel     odd kits 1, even kits 11
//    Your rover is already set up to join exactly this Wi-Fi. A wrong BOX_ID means: your rover
//    does not find your box, or your box takes over another team's network.
//
//  START ORDER: switch on the box first, then the rover (the rover looks for its box only
//    while it boots). Phone: join CAS-Box-<NN>, open the web page.
//
//  ARDUINO IDE: board "ESP32 Dev Module", ESP32 core 3.3.x, default partition scheme.
//    Required libraries and versions: README.md. Serial monitor: 115200 baud.
//
//  FILES
//    cas_box.ino        this file: settings, setup(), loop()
//    RoverLink.*        box -> rover link (sends drive commands, reads battery voltage)
//    Sensors.*          all sensors behind one object (ultrasonic, LiDAR, IMU, GPS)
//    LidarScan.h        LiDAR (LD20) reader with noise filtering
//    WebHMI.*           web server and web page
//    UsManager.*        5 ultrasonic sensors (HC-SR04), measured in a background task
//    ImuManager.*       orientation sensor BNO055 (roll / pitch / yaw in the ISO 8855 vehicle frame)
//    GpsManager.*       GPS module NEO-6M
//    DisplayManager.*   small OLED on the box
//
//  SAFETY / BEHAVIOUR
//    The rover stops when you release the key, when the page loses focus, when the box gets no
//    update from the phone for 0.4 s, when RoverLink gets no new set point for 0.5 s, and - in
//    the rover itself - after 3 s without a command. Do not remove these stops.
//    The rover firmware must not be changed.
// =============================================================================================

#include "WebHMI.h"
#include "RoverLink.h"
#include "Sensors.h"
#include "DisplayManager.h"
#include "DriveLog.h"
#include <esp_system.h>
#include <esp_wifi.h>
// Wi-Fi transmit power (from our repo, field-tested 01.11.: brownout restarts): low at start, 15 dBm running
#define WIFI_TX_START WIFI_POWER_8_5dBm
#define WIFI_TX_RUN WIFI_POWER_15dBm
#include <math.h>

// ---- YOUR KIT ------------------------------------------------------------------------------
const int BOX_ID = 4;                     // 1..10 = kit number on the box

// ---- settings --------------------------------------------------------------------------------
const float MAX_SPEED = 0.25f;            // drive pad maximum (slider steps 0.05: keep a multiple of 0.05)
const float RAMP_UP_S = 2.5f;             // 0 -> MAX_SPEED takes this long (linear), from standstill always
const float STOP_S = 0.5f;                // key released: MAX_SPEED -> 0 in this time (soft stop)
const float RIGHT_TURN_RAMP_S = 1.0f;     // 90-degree turns: 0 -> RIGHT_TURN_SPEED in this time
const float PIVOT_CMD = 0.35f;            // pad turn keys on the spot (0.25 is often too weak to turn)
const float PIVOT_RAMP_S = 1.0f;          // ... 0 -> PIVOT_CMD in this time
const uint32_t PAD_TIMEOUT_MS = 400;      // no update from the phone for this long -> stop
const int LIDAR_OFFSET_DEG = 90;          // rotates the LiDAR view so that "front" is up

const int US_FRONT_STOP_CM = 35;
const int US_SIDE_STOP_CM = 30;
const uint32_t US_WAIT_MS = 5000;
const uint32_t US_ARC_MS = 400; // bounded forward arc; not a measured turning angle
const float LEFT_WALL_TARGET_CM = 60.0f; // LiDAR centre to left wall
const uint32_t WALL_UPDATE_MS = 50;      // up to 20 Hz geometry processing
const float WALL_MAX_OFFSET_DEG = 8.0f;  // limited support around the saved gyro heading
const float RIGHT_TURN_SPEED = 0.35f; // constant automatic right-turn command
const float RIGHT_TURN_STOP_AT_DEG = 76.0f; // trial early stop: measured final overshoot was about 14 deg

// ---- objects ---------------------------------------------------------------------------------
WebHMI hmi;           // web server + page
RoverLink rover;      // connection to the rover
Sensors sensors;      // all box sensors
DisplayManager disp;  // small OLED on the box
DriveLog logger;      // drive recording to flash (web card "Drive log": Start / Stop / Mark / download)
bool oledReady = false;
String bootReason;    // why the box (re)started - shown on the page for 2 minutes (a restart ends a log)
char boxSsid[16], boxPassword[16];

// Lightweight left-wall observation; no map, pillar counting or route turns.
bool wallVisible=false;
float leftWallCm=0,leftWallAngleDeg=0,wallSteerDeg=0;
uint32_t wallViewMs=0,wallFrame=0;
void updateLeftWall() {
  const uint32_t now=millis();if(now-wallViewMs<WALL_UPDATE_MS)return;
  wallViewMs=now;++wallFrame;
  wallVisible=sensors.leftWall(leftWallCm,&leftWallAngleDeg);
  if(!wallVisible)leftWallCm=leftWallAngleDeg=0;
}

// Gradual start (2026-11-05). The pad command never jumps: each wheel rises LINEARLY from its current
// value towards the pad value at MAX_SPEED / RAMP_UP_S per second (0 -> 0.25 in 2.5 s, also when the
// slider is at 0.25), falls at MAX_SPEED / STOP_S per second (soft stop) and passes through 0 when the
// direction changes. It runs BEFORE the heading hold, so the hold steers around the ramped speed.
// An obstacle stop below (avoidUltrasonic) still stops at once; afterwards the ramp starts from 0 again.
float rampL = 0, rampR = 0;
void rampPad(float& l, float& r) {
  static uint32_t last = 0;
  const uint32_t now = millis();
  float dt = last ? (now - last) / 1000.0f : 0.0f;
  last = now;
  if (dt > 0.1f) dt = 0.1f;
  const bool pivot = (l > 0 && r < 0) || (l < 0 && r > 0);
  if (pivot) { const float d = r > 0 ? 1.0f : -1.0f; l = -d * PIVOT_CMD; r = d * PIVOT_CMD; }  // turn keys
  auto step = [&](float prev, float want) {
    if (prev != 0 && want != 0 && (prev > 0) != (want > 0)) want = 0;     // reverse: through 0 first
    const float upRate = pivot ? PIVOT_CMD / PIVOT_RAMP_S : MAX_SPEED / RAMP_UP_S;
    const float lim = (fabsf(want) > fabsf(prev) ? upRate : MAX_SPEED / STOP_S) * dt;
    const float n = prev + constrain(want - prev, -lim, lim);
    return fabsf(n) < 0.001f ? 0.0f : n;
  };
  rampL = step(rampL, l);
  rampR = step(rampR, r);
  l = rampL;
  r = rampR;
}

// Gyro-based heading hold for the forward arrow only; manual turns/reverse are unchanged.
String obstacleStatus;
bool headingHolding = false;
float headingTargetDeg = 0, headingCorrection = 0;
uint32_t headingControlMs = 0;

float headingErrorDeg(float target, float yaw) {
  float e = fmodf(target - yaw + 180.0f, 360.0f);
  if (e < 0) e += 360.0f;
  return e - 180.0f;
}

void steerForward(float& l, float& r) {
  static float previousYaw = 0, yawRate = 0, baseHeading = 0;
  static uint32_t lastWallFrame=0,wallSince=0;
  const bool forward = l > 0 && r > 0 && fabsf(l-r) < 0.0001f;
  if (!forward || !sensors.headingReady()) {
    headingHolding = false; headingCorrection = 0; headingControlMs = 0;
    wallSteerDeg=0;wallSince=0;
    if (forward) l = r = 0; // No gyro steering with a missing/invalid reading.
    return;
  }
  const uint32_t now = millis();
  const float yaw = sensors.yawNowDeg();
  if (!headingHolding) {
    headingHolding = true; baseHeading=headingTargetDeg=yaw; previousYaw=yaw;
    wallSteerDeg=0;wallSince=0;lastWallFrame=wallFrame;
    yawRate = headingCorrection = 0; headingControlMs = now;
  }
  if(lastWallFrame!=wallFrame){
    lastWallFrame=wallFrame;
    if(wallVisible){
      if(!wallSince)wallSince=now;
      if(now-wallSince>=400&&obstacleStatus.length()==0){
        const float distanceError=leftWallCm-LEFT_WALL_TARGET_CM;
        const float outsideBand=fabsf(distanceError)<=5?0:distanceError-(distanceError>0?5:-5);
        const float wallHeading=headingErrorDeg(yaw+leftWallAngleDeg,0);
        const float wanted=constrain(0.25f*headingErrorDeg(wallHeading,baseHeading)+0.15f*outsideBand,
                                     -WALL_MAX_OFFSET_DEG,WALL_MAX_OFFSET_DEG);
        wallSteerDeg+=constrain(wanted-wallSteerDeg,-0.05f,0.05f); // 1 degree/second
      }
    }else wallSince=0; // Keep the last guided heading through a wall gap.
    headingTargetDeg=headingErrorDeg(baseHeading+wallSteerDeg,0);
  }
  if (now - headingControlMs >= 10) { // up to 100 Hz
    const float dt = (now - headingControlMs) / 1000.0f;
    headingControlMs = now;
    const float retain = powf(0.7f, dt / 0.02f);
    yawRate = dt < 0.1f ? retain*yawRate + (1-retain)*headingErrorDeg(yaw,previousYaw)/dt : 0;
    previousYaw = yaw;
    const float error = headingErrorDeg(headingTargetDeg,yaw);
    const float limit = fminf(0.10f,l*0.4f);
    const float wanted = constrain((fabsf(error)>0.5f ? 0.045f*error : 0)-0.0015f*yawRate,-limit,limit); // stronger forward heading correction
    if (dt >= 0.1f) headingCorrection = 0;
    else headingCorrection += constrain(wanted-headingCorrection,-0.30f*dt,0.30f*dt);
    headingCorrection = constrain(headingCorrection,-limit,limit);
  }
  const float speed = l;
  l = speed-headingCorrection; r = speed+headingCorrection;
  const float peak = fmaxf(l,r);
  if (peak > MAX_SPEED) { l *= MAX_SPEED/peak; r *= MAX_SPEED/peak; }
}

// Forward-arrow obstacle handling. Release/manual control cancels an automatic arc.
void avoidUltrasonic(bool forwardRequested, float& l, float& r) {
  enum Phase { DRIVE, WAIT, ARC, BLOCKED };
  static Phase phase = DRIVE;
  static uint32_t waitStarted = 0, clearSince = 0, arcStarted = 0;
  static int turn = 0, attempts = 0;
  if (!forwardRequested) { phase=DRIVE; attempts=0; clearSince=0; obstacleStatus=""; return; }
  const uint32_t now=millis();
  const int cm[3]={sensors.usCm(0),sensors.usCm(1),sensors.usCm(2)};
  const char* name[3]={"Front","Left","Right"};
  auto limit=[&](int i){return i==0?US_FRONT_STOP_CM:US_SIDE_STOP_CM;};
  auto invalid=[&](int i){return cm[i]!=-2&&(cm[i]<2||cm[i]>Sensors::kUsMaxCm);};
  auto close=[&](int i){return cm[i]>=2&&cm[i]<=limit(i);};
  // No echo is allowed for ordinary forward driving, but never approves an avoidance arc.
  auto clear=[&](int i){return cm[i]==-2||cm[i]>limit(i);};
  int bad=-1,hit=-1;
  for(int i=0;i<3;++i){if(invalid(i)&&bad<0)bad=i;if(close(i)&&hit<0)hit=i;}
  const float speed=fminf(0.20f,fmaxf(l,r));
  if (!sensors.headingReady()) { l=r=0; obstacleStatus="STOP: IMU invalid/stale"; return; }
  if (bad>=0) {
    l=r=0; clearSince=0;
    if(phase==ARC){phase=WAIT;waitStarted=now;}
    obstacleStatus=String("STOP: US ")+name[bad]+" invalid/stale";return;
  }
  if(phase==BLOCKED){l=r=0;obstacleStatus="STOP: avoidance limit; release forward to reset";return;}
  if(phase==DRIVE && hit<0){obstacleStatus="";return;}
  if(phase==DRIVE){phase=WAIT;waitStarted=now;clearSince=0;}
  if(phase==WAIT){
    l=r=0;
    if(clear(0)&&clear(1)&&clear(2)){if(!clearSince)clearSince=now;}else clearSince=0;
    const String source=hit>=0?String("US ")+name[hit]+" "+String(cm[hit])+" cm":"US clearance";
    if(now-waitStarted<US_WAIT_MS){obstacleStatus="Wait 5 seconds: "+source;return;}
    if(clearSince&&now-clearSince>=600){phase=DRIVE;attempts=0;obstacleStatus="Path cleared; resuming saved heading";return;}
    if(close(0)||!clear(0)){obstacleStatus="STOP: US Front blocked; automatic pivots disabled";return;}
    // Require measured front and destination-side clearance, not a no-echo assumption.
    turn=close(2)&&cm[0]>US_FRONT_STOP_CM+10&&cm[1]>US_SIDE_STOP_CM+10?1:
         close(1)&&cm[0]>US_FRONT_STOP_CM+10&&cm[2]>US_SIDE_STOP_CM+10?-1:0;
    if(!turn){obstacleStatus="STOP: no measured clearance for forward arc | "+source;return;}
    if(attempts>=3){phase=BLOCKED;obstacleStatus="STOP: avoidance limit; release forward to reset";return;}
    ++attempts;phase=ARC;arcStarted=now;
  }
  if(phase==ARC){
    const int destination=turn>0?1:2;
    if(cm[0]<=US_FRONT_STOP_CM+10||cm[destination]<=US_SIDE_STOP_CM+10||now-arcStarted>=US_ARC_MS){
      l=r=0;phase=WAIT;waitStarted=now;clearSince=0;
      obstacleStatus="Arc ended; checking ultrasonic clearance";return;
    }
    // Both sides forward. The saved IMU target is retained throughout the pause/arc.
    l=turn>0?speed*0.4f:speed;r=turn>0?speed:speed*0.4f;
    obstacleStatus=turn>0?"US Right: forward arc left":"US Left: forward arc right";
  }
}

// Deliberate 90-degree test: original right-arrow pivot, separate from forward avoidance.
bool rightTurnActive=false;
float rightTurnTargetDeg=0,rightTurnProgressDeg=0;
String rightTurnStatus;
bool controlRightTurn90(uint32_t token,uint32_t ageMs,float& l,float& r) {
  static uint32_t currentToken=0,started=0,lastControl=0,responseMs=0;
  static float previousYaw=0,responseProgress=0,command=0;
  static int8_t sgn=-1;   // +1 left, -1 right (Left 90 / Right 90 button)
  if(!token){
    if(rightTurnActive)rightTurnStatus="Turn 90 cancelled";
    rightTurnActive=false;return false;
  }
  l=r=0;
  auto finish=[&](const String& reason){
    rightTurnActive=false;rightTurnStatus=reason;hmi.finishRightTurn(token);l=r=0;
  };
  const uint32_t now=millis();
  if(token!=currentToken){
    currentToken=token;rightTurnActive=true;started=responseMs=now;lastControl=0;
    rightTurnProgressDeg=responseProgress=0;command=0;sgn=hmi.turnDir();
    if(sensors.headingReady())previousYaw=sensors.yawNowDeg();
    rightTurnTargetDeg=headingErrorDeg(previousYaw+90*sgn,0);
  }
  if(!rightTurnActive)return true; // A completed token cannot restart via a late heartbeat.
  if(ageMs>PAD_TIMEOUT_MS){finish("STOP: turn 90 phone timeout");return true;}
  if(!rover.connected()){finish("STOP: turn 90 rover disconnected");return true;}
  if(!sensors.headingReady()){finish("STOP: turn 90 IMU invalid/stale");return true;}
  const char* names[3]={"Front","Left","Right"};
  for(int i=0;i<3;++i){
    const int cm=sensors.usCm(i),limit=i==0?US_FRONT_STOP_CM:US_SIDE_STOP_CM;
    if(cm!=-2&&(cm<2||cm>Sensors::kUsMaxCm||cm<=limit)){
      finish(String("STOP: turn 90 | US ")+names[i]+" "+(cm<2?String("invalid/stale"):String(cm)+" cm"));return true;
    }
  }
  if(now-started>15000){finish("STOP: turn 90 exceeded 15 seconds");return true;}
  if(lastControl&&now-lastControl<10){l=-sgn*command;r=sgn*command;return true;}
  lastControl=now;
  const float yaw=sensors.yawNowDeg();
  const float delta=headingErrorDeg(yaw,previousYaw);previousYaw=yaw;
  if(fabsf(delta)>30){finish("STOP: turn 90 unexpected IMU jump");return true;}
  rightTurnProgressDeg+=sgn*delta; // right: yaw decreases, left: increases; accumulate through +/-180.
  if(rightTurnProgressDeg< -5){finish("STOP: turn 90 turned the wrong direction");return true;}
  if(rightTurnProgressDeg>=RIGHT_TURN_STOP_AT_DEG){finish("Turn 90: early stop commanded; check final yaw");return true;}
  if(rightTurnProgressDeg-responseProgress>=1){responseProgress=rightTurnProgressDeg;responseMs=now;}
  if(now-responseMs>2000){finish("STOP: turn 90 no measured turn response");return true;}
  command=fminf(RIGHT_TURN_SPEED,command+RIGHT_TURN_SPEED*0.01f/RIGHT_TURN_RAMP_S); // gradual (10 ms steps)
  l=-sgn*command;r=sgn*command;
  rightTurnStatus=String(sgn>0?"Left":"Right")+" 90: "+String(rightTurnProgressDeg,1)+" / 90 deg";
  return true;
}

// OLED: Wi-Fi name, web address, rover state. Started only when the display answers on I2C.
void updateOled() {
  static uint32_t lastTry = 0;
  if (!oledReady) {
    if (millis() - lastTry < 5000) return;
    lastTry = millis();
    if (!i2cPresent(0x3C)) return;
    oledReady = disp.begin();
  }
  String ip = WiFi.softAPIP().toString();
  String r = rover.connected() ? "Rover " + String(rover.voltage(), 1) + "V" : "Rover: search";
  disp.show(boxSsid, ip.c_str(), r.c_str());
}

void setup() {
  Serial.begin(115200);
  delay(200);
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: bootReason = "power on"; break;
    case ESP_RST_BROWNOUT: bootReason = "BROWNOUT (supply voltage dropped)"; break;
    case ESP_RST_PANIC: bootReason = "CRASH (panic)"; break;
    case ESP_RST_INT_WDT: case ESP_RST_TASK_WDT: case ESP_RST_WDT: bootReason = "WATCHDOG (box hung)"; break;
    case ESP_RST_SW: bootReason = "software restart"; break;
    case ESP_RST_EXT: bootReason = "reset button"; break;
    default: bootReason = "reset code " + String((int)esp_reset_reason()); break;
  }
  Serial.printf("[boot] reason: %s\n", bootReason.c_str());

  // naming scheme, derived from BOX_ID only (see header)
  snprintf(boxSsid, sizeof(boxSsid), "CAS-Box-%02d", BOX_ID);
  snprintf(boxPassword, sizeof(boxPassword), "CASbox%02d", BOX_ID);
  uint8_t channel = (BOX_ID % 2) ? 1 : 11;

  hmi.setTitle(String("CAS Box ") + BOX_ID);
  hmi.enableDrivePad(MAX_SPEED);
  hmi.setStateText("Starting ...");
  WiFi.mode(WIFI_AP);
  WiFi.setTxPower(WIFI_TX_START);        // smaller current spike at start (brownout fix, our repo 01.11.)
  hmi.begin(boxSsid, boxPassword, IPAddress(192, 168, 10 + BOX_ID, 1), channel);
  wifi_config_t apCfg;                   // rover wakes at every beacon: less delay box -> rover
  if (esp_wifi_get_config(WIFI_IF_AP, &apCfg) == ESP_OK) { apCfg.ap.dtim_period = 1; esp_wifi_set_config(WIFI_IF_AP, &apCfg); }
  WiFi.setTxPower(WIFI_TX_RUN);          // 15 dBm instead of 19.5: smaller current peaks
  logger.begin(hmi.server());   // LittleFS + web card "Drive log" (first boot formats the flash once)

  delay(500);                            // let the supply recover from the Wi-Fi start before the LiDAR motor
  sensors.begin(LIDAR_OFFSET_DEG);
  rover.begin(100);  // sends the current drive command every 100 ms
}

void loop() {
  uint32_t t0 = micros();
  hmi.tick();
  sensors.update();
  updateLeftWall();

  // ---- driving -------------------------------------------------------------------------------
  // Manual driving from the phone. For your own (autonomous) behaviour, compute l and r
  // yourself from the sensors, e.g. sensors.usCm(0) = front ultrasonic in cm, and call
  // rover.setDrive(l, r) every loop pass (range -0.5..0.5 per side).
  float l, r;
  uint32_t age;
  hmi.getDrive(l, r, age);
  if (age > PAD_TIMEOUT_MS) l = r = 0;  // key released, page closed or phone gone
  const float padL = l, padR = r;       // what the key asks for (logged as cmd)
  rampPad(l, r);                        // gradual start / soft stop (see rampPad)
  uint32_t turnToken,turnAge;hmi.getRightTurn(turnToken,turnAge);
  if(controlRightTurn90(turnToken,turnAge,l,r)){
    float zeroL=0,zeroR=0;steerForward(zeroL,zeroR);avoidUltrasonic(false,zeroL,zeroR);
  }else{
    if(l!=0||r!=0)rightTurnStatus="";
    const bool forwardRequested = l>0 && r>0 && fabsf(l-r)<0.0001f;
    steerForward(l, r);
    avoidUltrasonic(forwardRequested,l,r);
  }
  if (l == 0 && r == 0) rampL = rampR = 0;   // stopped (obstacle, IMU, turn): next start ramps from 0
  rover.setDrive(l, r);

  // ---- drive log (one record every 250 ms while "Start" is active) ------------------------------
  DriveLog::Sample smp;
  smp.cmdL = padL; smp.cmdR = padR;     // key
  smp.outL = l; smp.outR = r;           // what went to the rover
  smp.safety = obstacleStatus.length() ? 2 : 0;   // 2 = obstacle handling active (stop / wait / arc)
  smp.batteryV = rover.voltage();
  smp.rttMs = rover.rttMs();
  smp.ctrlDeg = headingHolding && sensors.headingReady() ? headingErrorDeg(headingTargetDeg, sensors.yawNowDeg()) : 0;
  logger.update(sensors, smp);

  // ---- web page and OLED -----------------------------------------------------------------------
  uint32_t now = millis();
  static uint32_t lastSnap = 0, lastUi = 0, lastOled = 0;
  if (now - lastSnap >= 250) {  // sensor snapshot for the page, 4 times per second
    lastSnap = now;
    hmi.setSensorJson(sensors.toJson());
  }
  if (now - lastUi >= 500) {  // status line + values in the "Dev" view
    lastUi = now;
    const String guidance=headingHolding?(wallVisible?" | Forward: left wall "+String(leftWallCm,0)+" cm; target 60 cm":" | Forward: gyro holds heading; left wall not visible"):"";
    const String restarted = (millis() < 120000 && bootReason != "power on") ? "BOX RESTARTED: " + bootReason + " | " : "";
    hmi.setStateText(restarted+String(logger.active() ? "● REC | " : "")+rover.statusText()+(rightTurnStatus.length()?" | "+rightTurnStatus:obstacleStatus.length()?" | "+obstacleStatus:guidance));
    hmi.showValue("boot", bootReason);
    hmi.showValue("rover.voltage_V", rover.voltage());
    hmi.showValue("rover.rtt_ms", rover.rttMs());
    hmi.showValue("rover.ok_fail", String((unsigned long)rover.okCount()) + " / " + String((unsigned long)rover.failCount()));
    hmi.showValue("drive.out", String(rampL, 2) + " / " + String(rampR, 2));
    hmi.showValue("sys.heap_kB", ESP.getFreeHeap() / 1024.0);
    hmi.showValue("turn.target_deg",rightTurnTargetDeg);
    hmi.showValue("turn.progress_deg",rightTurnProgressDeg);
    hmi.showValue("wall.seen",wallVisible?1:0);
    hmi.showValue("wall.distance_cm",leftWallCm);
    hmi.showValue("log", logger.statusText());
    hmi.showValue("wall.steer_deg",wallSteerDeg);
    hmi.showValue("wall.angle_deg",leftWallAngleDeg);
    hmi.showValue("imu.holding",headingHolding ? 1 : 0);
    hmi.showValue("imu.target_deg",headingTargetDeg);
    hmi.showValue("imu.error_deg",sensors.headingReady() ? headingErrorDeg(headingTargetDeg,sensors.yawNowDeg()) : 0);
  }
  if (now - lastOled >= 1000) {
    lastOled = now;
    updateOled();
  }

  // ---- load report on Serial every 10 s (loop time, free memory, sensor snapshot) -------------
  static uint32_t lastRep = 0, n = 0, maxUs = 0;
  static uint64_t sumUs = 0;
  uint32_t dt = micros() - t0;
  n++; sumUs += dt; if (dt > maxUs) maxUs = dt;
  if (now - lastRep >= 10000) {
    Serial.printf("[sys] loop avg %.2f ms max %.1f ms, heap %u kB, rover %s\n",
                  sumUs / 1000.0 / n, maxUs / 1000.0, ESP.getFreeHeap() / 1024,
                  rover.connected() ? "ok" : "searching");
    Serial.printf("[sys] %s\n", sensors.toJson().c_str());
    lastRep = now; n = 0; sumUs = 0; maxUs = 0;
  }
  delay(2);
}
