# cas_box_kethan_log – teaching drives with Kethan's code

Kethan's field-tested code (heading hold, IMU checks, ultrasonic avoidance, right-90) **plus**:
- **DriveLog** (from our repo): web card "Drive log" with Start / Stop / Mark (with tags) / Undo / download. One record every 250 ms → `/log_NNN.bin`. Decode with `tools/analyze_log.py`.
- **Gradual start for every key:** each wheel rises from 0 to the slider value at 0.1 per second (0 → 0.25 in 2.5 s), also when the slider is at 0.25. Release → soft stop in ≤ 0.5 s. Changing direction passes through 0. An obstacle stop is still immediate, and afterwards it ramps from 0 again.
- **Right-90 pivot:** 0 → 0.35 in 1 s instead of a jump.
- `MAX_SPEED` 0.25. Dev view: `drive.out` (ramped wheel commands), `log` (recording status).

Flash: Arduino IDE, ESP32 Dev Module, **Partition Scheme "Default"** (it holds ~1.3 MB of logs, about 25 min of driving). Sketch is 94 %.
```
arduino-cli compile --fqbn esp32:esp32:esp32:UploadSpeed=115200 cas_box_kethan_log
arduino-cli upload  --fqbn esp32:esp32:esp32:UploadSpeed=115200 -p /dev/cu.usbserial-XXXX cas_box_kethan_log
```

## Teaching drive (2–3 sets)
1. The box must stand still on the ground when you switch it on (yaw 0 = first valid reading).
2. Rover parallel to the wall at the start. Press **Start** (REC), then **Mark** with tag "start".
3. Hold **forward** on straights; the heading hold keeps it straight. Use the turn keys only at real corners.
4. At the end of every segment: choose the tag (how it was driven + what ends it), then **Mark**.
5. **Stop** at the end, download the file, delete it on the box before the next set (storage ~25 min).

## Drive pad (update 05.11. 12:30)
```
 ↖   ▲   ↗        ▲      forward, holds the heading it has when you press it
 ◀   ■   ▶        ↖ ↗   forward with a gentle curve (inner wheel 50 %): drift correction while rolling
     ▼            ◀ ▶   turn on the spot at 0.35 (ramped up in 1 s), whatever the slider says
[Left 90°] [Right 90°]  gyro-controlled 90° turn (ramped up in 1 s), stops by itself; ■ cancels
```
**Drift correction while teaching:** release ▲, tap ↖ or ↗ for about half a second until the nose points along the path again, then press ▲. The hold then keeps the new heading. The rover keeps rolling the whole time: no pivot, no stop.
Note: ↖ ↗ and ◀ ▶ have no automatic obstacle stop (Kethan's avoidance only acts on ▲), so watch the rover.
